const API_URL = 'http://localhost:8080/jogos';

document.getElementById('form-jogo').addEventListener('submit', async (e) => {
  e.preventDefault();

  const jogo = {
    nome: document.getElementById('nome').value,
    ano: document.getElementById('ano').value,
    tipo: document.getElementById('tipo').value,
    avaliacao: document.getElementById('avaliacao').value
  };

  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(jogo)
  });

  if (res.ok) {
    alert('Jogo cadastrado com sucesso!');
    carregarJogos();
  }
});

async function carregarJogos() {
  const res = await fetch(API_URL);
  const jogos = await res.json();
  const lista = document.getElementById('lista-jogos');
  lista.innerHTML = '';

  jogos.forEach(jogo => {
    const li = document.createElement('li');
    li.textContent = `${jogo.nome} (${jogo.ano}) - ${jogo.tipo} - Nota: ${jogo.avaliacao}`;
    lista.appendChild(li);
  });
}

carregarJogos();
