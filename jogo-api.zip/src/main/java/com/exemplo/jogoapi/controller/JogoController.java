package com.exemplo.jogoapi.controller;

import com.exemplo.jogoapi.model.Jogo;
import com.exemplo.jogoapi.repository.JogoRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jogos")
@CrossOrigin(origins = "*")
public class JogoController {

    private final JogoRepository repository;

    public JogoController(JogoRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Jogo> listar() {
        return repository.findAll();
    }

    @PostMapping
    public Jogo adicionar(@RequestBody Jogo jogo) {
        return repository.save(jogo);
    }

    @PutMapping("/{id}")
    public Jogo atualizar(@PathVariable Long id, @RequestBody Jogo jogo) {
        jogo.setId(id);
        return repository.save(jogo);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable Long id) {
        repository.deleteById(id);
    }
}
