package com.exemplo.jogoapi.repository;

import com.exemplo.jogoapi.model.Jogo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JogoRepository extends JpaRepository<Jogo, Long> {}
